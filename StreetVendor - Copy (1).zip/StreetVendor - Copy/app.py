from flask import Flask, render_template, request, redirect, url_for, jsonify, session
import json
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this for production

# Database file paths
VENDOR_DB = 'vendor_database.json'
SUPPLIER_DB = 'supplier_database.json'

def init_db(db_file):
    if not os.path.exists(db_file):
        with open(db_file, 'w') as f:
            json.dump({"users": []}, f)
    else:
        try:
            with open(db_file, 'r') as f:
                json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            with open(db_file, 'w') as f:
                json.dump({"users": []}, f)

def read_db(db_file):
    try:
        with open(db_file, 'r') as f:
            data = json.load(f)
            if 'users' not in data:
                data = {'users': []}
            return data
    except (json.JSONDecodeError, FileNotFoundError):
        init_db(db_file)
        return {'users': []}

def write_db(db_file, data):
    with open(db_file, 'w') as f:
        json.dump(data, f, indent=4)

def user_exists(db_file, email):
    db = read_db(db_file)
    return any(user['email'] == email for user in db['users'])

def add_user(db_file, name, email, phone, password, place, business):
    db = read_db(db_file)
    db['users'].append({
        'name': name,
        'email': email,
        'phone': phone,
        'password': generate_password_hash(password),
        'place': place,
        'business': business
    })
    write_db(db_file, db)

def verify_user(db_file, email, password):
    db = read_db(db_file)
    user = next((user for user in db['users'] if user['email'] == email), None)
    if user and check_password_hash(user['password'], password):
        return user
    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    user_type = data.get('user_type')
    name = data.get('name')
    email = data.get('email')
    phone = data.get('phone')
    password = data.get('password')
    place = data.get('place')
    business = data.get('business')
    
    if not all([user_type, name, email, phone, password, place, business]):
        return jsonify({"success": False, "message": "All fields are required"}), 400
    
    db_file = VENDOR_DB if user_type == 'vendor' else SUPPLIER_DB
    
    if user_exists(db_file, email):
        return jsonify({"success": False, "message": "Email already registered"}), 400
    
    add_user(db_file, name, email, phone, password, place, business)
    return jsonify({"success": True, "message": "Account created successfully"})

@app.route('/signin', methods=['POST'])
def signin():
    data = request.get_json()
    user_type = data.get('user_type')
    email = data.get('email')
    password = data.get('password')
    
    if not all([user_type, email, password]):
        return jsonify({"success": False, "message": "Email and password are required"}), 400
    
    db_file = VENDOR_DB if user_type == 'vendor' else SUPPLIER_DB
    user = verify_user(db_file, email, password)
    
    if not user:
        return jsonify({"success": False, "message": "Invalid credentials"}), 401
    
    session['user'] = {
        'name': user['name'],
        'email': user['email'],
        'phone': user['phone'],
        'place': user['place'],
        'business': user['business'],
        'type': user_type
    }
    return jsonify({"success": True, "message": "Login successful", "user": user['name'], "user_type": user_type})

@app.route('/home')
def home():
    if 'user' not in session:
        return redirect(url_for('index'))
    
    # Redirect based on user type
    user_type = session['user']['type']
    if user_type == 'vendor':
        return render_template('vendor_home.html', user=session['user'])
    else:
        return render_template('supplier_home.html', user=session['user'])
@app.route('/sell')
def sell():
    return render_template('sell.html')

@app.route('/vendor_home')
def vendor_home():
    return render_template('vendor_home.html')

@app.route('/market_analysis')
def market_analysis():
    return render_template('market_analysis.html')

@app.route('/purchase_history')
def purchase_history():
     return render_template('purchase_history.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('index'))


if __name__ == '__main__':
    init_db(VENDOR_DB)
    init_db(SUPPLIER_DB)
    app.run(debug=True, port=5000)