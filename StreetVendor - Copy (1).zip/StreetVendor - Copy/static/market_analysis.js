document.addEventListener('DOMContentLoaded', function() {
  // Theme Toggle
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const body = document.body;
  
  // Check for saved theme preference
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) {
    body.classList.add(savedTheme);
    updateThemeIcon();
  }
  
  themeToggleBtn.addEventListener('click', function() {
    body.classList.toggle('dark-theme');
    const currentTheme = body.classList.contains('dark-theme') ? 'dark-theme' : 'light-theme';
    localStorage.setItem('theme', currentTheme);
    updateThemeIcon();
  });
  
  function updateThemeIcon() {
    const icon = themeToggleBtn.querySelector('i');
    if (body.classList.contains('dark-theme')) {
      icon.classList.remove('fa-moon');
      icon.classList.add('fa-sun');
    } else {
      icon.classList.remove('fa-sun');
      icon.classList.add('fa-moon');
    }
  }
  
  // User Dropdown
  const userDropdownBtn = document.getElementById('userDropdownBtn');
  const userDropdown = document.getElementById('userDropdown');
  
  userDropdownBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    userDropdown.classList.toggle('show');
  });
  
  // Close dropdown when clicking outside
  document.addEventListener('click', function() {
    userDropdown.classList.remove('show');
  });
  
  // Sign Out
  const signOutBtn = document.getElementById('signOutBtn');
  signOutBtn.addEventListener('click', function() {
    fetch('/logout', {
      method: 'POST'
    }).then(() => {
      window.location.href = '/';
    });
  });

  // Price Trend Chart
  const priceTrendCtx = document.getElementById('priceTrendChart').getContext('2d');
  const priceTrendChart = new Chart(priceTrendCtx, {
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [
        {
          label: 'Tomatoes (₹/kg)',
          data: [42, 45, 48, 50, 47, 52, 55, 60, 58, 55, 50, 48],
          borderColor: '#28a745',
          backgroundColor: 'rgba(40, 167, 69, 0.1)',
          tension: 0.3,
          fill: true
        },
        {
          label: 'Potatoes (₹/kg)',
          data: [25, 28, 30, 32, 30, 28, 25, 27, 30, 32, 35, 38],
          borderColor: '#ffc107',
          backgroundColor: 'rgba(255, 193, 7, 0.1)',
          tension: 0.3,
          fill: true
        },
        {
          label: 'Onions (₹/kg)',
          data: [20, 22, 25, 28, 30, 32, 35, 40, 38, 35, 30, 28],
          borderColor: '#dc3545',
          backgroundColor: 'rgba(220, 53, 69, 0.1)',
          tension: 0.3,
          fill: true
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Monthly Price Trends',
          font: {
            size: 16
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      },
      scales: {
        y: {
          beginAtZero: false
        }
      }
    }
  });

  // Customer Demographics Pie Chart
   const customerDemographicsCtx = document.getElementById('customerDemographics').getContext('2d');
  const customerDemographicsChart = new Chart(customerDemographicsCtx, {
    type: 'doughnut',
    data: {
      labels: ['Age 18-25', 'Age 26-35', 'Age 36-45', 'Age 46-55', 'Age 56-65', 'Age 65+'],
      datasets: [{
        data: [20, 35, 25, 12, 5, 3],
        backgroundColor: [
          '#28a745',
          '#007bff',
          '#ffc107',
          '#fd7e14',
          '#dc3545',
          '#6f42c1'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Customer Age Distribution',
          font: {
            size: 16
          }
        }
      }
    }
  });

  // Seasonal Forecast Chart
  const seasonalForecastCtx = document.getElementById('seasonalForecast').getContext('2d');
  const seasonalForecastChart = new Chart(seasonalForecastCtx, {
    type: 'bar',
    data: {
      labels: ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [
        {
          label: 'Expected Tomato Demand',
          data: [80, 85, 90, 95, 85, 75, 70, 75, 80, 85, 90, 95],
          backgroundColor: 'rgba(40, 167, 69, 0.7)',
          borderColor: '#28a745',
          borderWidth: 1
        },
        {
          label: 'Expected Potato Demand',
          data: [70, 75, 80, 85, 90, 85, 80, 75, 70, 65, 70, 75],
          backgroundColor: 'rgba(255, 193, 7, 0.7)',
          borderColor: '#ffc107',
          borderWidth: 1
        },
        {
          label: 'Expected Onion Demand',
          data: [65, 70, 75, 80, 85, 90, 95, 90, 85, 80, 75, 70],
          backgroundColor: 'rgba(220, 53, 69, 0.7)',
          borderColor: '#dc3545',
          borderWidth: 1
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Seasonal Demand Forecast',
          font: {
            size: 16
          }
        }
      },
      scales: {
        y: {
          beginAtZero: false,
          suggestedMin: 50
        }
      }
    }
  });