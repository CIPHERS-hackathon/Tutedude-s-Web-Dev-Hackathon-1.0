document.addEventListener('DOMContentLoaded', function() {
  // Theme Toggle
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  themeToggleBtn.addEventListener('click', toggleTheme);
  
  // Auth Modal Toggle
  const authModal = document.getElementById('authModal');
  const closeModalBtn = document.getElementById('closeModalBtn');

  // Track active user type (vendor/supplier)
  let activeUserType = 'vendor';

  // Vendor/Supplier card buttons
  const openAuthButtons = document.querySelectorAll('.open-auth-modal');
  openAuthButtons.forEach(button => {
    button.addEventListener('click', () => {
      authModal.classList.add('active');
      // Set active user type based on clicked button
      activeUserType = button.dataset.user;
      // Mark the clicked button as active
      openAuthButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
    });
  });

  closeModalBtn.addEventListener('click', () => {
    authModal.classList.remove('active');
  });
  
  authModal.addEventListener('click', (e) => {
    if (e.target === authModal) {
      authModal.classList.remove('active');
    }
  });
  
  // Auth Tabs
  const authTabs = document.querySelectorAll('.auth-tab');
  const authForms = document.querySelectorAll('.auth-form');
  
  authTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const tabName = tab.getAttribute('data-tab');
      
      // Update active tab
      authTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      // Show corresponding form
      authForms.forEach(form => {
        form.classList.remove('active');
        if (form.id === `${tabName}Form`) {
          form.classList.add('active');
        }
      });
    });
  });
  
  // Carousel Functionality
  const carouselItems = document.querySelectorAll('.carousel-item');
  const prevBtn = document.querySelector('.prev-btn');
  const nextBtn = document.querySelector('.next-btn');
  const indicatorsContainer = document.querySelector('.carousel-indicators');
  let currentIndex = 0;
  
  // Create indicators
  carouselItems.forEach((_, index) => {
    const indicator = document.createElement('div');
    indicator.classList.add('carousel-indicator');
    if (index === 0) indicator.classList.add('active');
    indicator.addEventListener('click', () => {
      goToSlide(index);
    });
    indicatorsContainer.appendChild(indicator);
  });
  
  const indicators = document.querySelectorAll('.carousel-indicator');
  
  // Auto rotate carousel
  let carouselInterval = setInterval(nextSlide, 5000);
  
  function nextSlide() {
    goToSlide((currentIndex + 1) % carouselItems.length);
  }
  
  function prevSlide() {
    goToSlide((currentIndex - 1 + carouselItems.length) % carouselItems.length);
  }
  
  function goToSlide(index) {
    carouselItems[currentIndex].classList.remove('active');
    indicators[currentIndex].classList.remove('active');
    
    currentIndex = index;
    
    carouselItems[currentIndex].classList.add('active');
    indicators[currentIndex].classList.add('active');
    
    // Reset timer when manually changing slide
    clearInterval(carouselInterval);
    carouselInterval = setInterval(nextSlide, 5000);
  }
  
  prevBtn.addEventListener('click', prevSlide);
  nextBtn.addEventListener('click', nextSlide);
  
 // Signin Form Submission
  const signinForm = document.getElementById('signinForm');
  signinForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('signin-email').value.trim();
    const password = document.getElementById('signin-password').value.trim();
    
    if (!email || !password) {
      alert('Email and password are required');
      return;
    }

    try {
      const response = await fetch('/signin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email, 
          password,
          user_type: activeUserType  // Make sure this is passed correctly
        })
      });
      
      const data = await response.json();
      if (data.success) {
        window.location.href = '/home';  // The server will redirect to the appropriate home page
      } else {
        alert(data.message || 'Login failed. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again.');
    }
  });

  
  // Signup Form Submission (Updated with validation)
  const signupForm = document.getElementById('signupForm');
  signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Get all form values
    const name = document.getElementById('signup-name').value.trim();
    const place = document.getElementById('signup-place').value.trim();
    const phone = document.getElementById('signup-phone').value.trim();
    const business = document.getElementById('signup-business').value.trim();
    const email = document.getElementById('signup-email').value.trim();
    const password = document.getElementById('signup-password').value.trim();

    // Validate all fields
    if (!name || !place || !phone || !business || !email || !password) {
      alert('Please fill in all fields');
      return;
    }

    // Validate email format
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      alert('Please enter a valid email address');
      return;
    }

    // Validate phone number (basic validation)
    if (!/^\d{10,15}$/.test(phone)) {
      alert('Please enter a valid phone number (10-15 digits)');
      return;
    }

    // Validate password length
    if (password.length < 6) {
      alert('Password must be at least 6 characters');
      return;
    }

    try {
      const response = await fetch('/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          name, 
          place, 
          phone, 
          business, 
          email, 
          password,
          user_type: activeUserType
        })
      });
      
      const data = await response.json();
      if (data.success) {
        window.location.href = '/home';
      } else {
        alert(data.message || 'Registration failed. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again.');
    }
  });
});

function toggleTheme() {
  document.body.classList.toggle('dark-theme');
  const icon = document.querySelector('#themeToggleBtn i');
  
  if (document.body.classList.contains('dark-theme')) {
    icon.classList.remove('fa-moon');
    icon.classList.add('fa-sun');
  } else {
    icon.classList.remove('fa-sun');
    icon.classList.add('fa-moon');
  }
}