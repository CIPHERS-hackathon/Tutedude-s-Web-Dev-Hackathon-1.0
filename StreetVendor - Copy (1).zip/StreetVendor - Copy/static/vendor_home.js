document.addEventListener('DOMContentLoaded', function() {
  // Theme Toggle
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const body = document.body;
  
  // Check for saved theme preference
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) {
    body.classList.add(savedTheme);
    updateThemeIcon();
  }
  
  themeToggleBtn.addEventListener('click', function() {
    body.classList.toggle('dark-theme');
    const currentTheme = body.classList.contains('dark-theme') ? 'dark-theme' : 'light-theme';
    localStorage.setItem('theme', currentTheme);
    updateThemeIcon();
  });
  
  function updateThemeIcon() {
    const icon = themeToggleBtn.querySelector('i');
    if (body.classList.contains('dark-theme')) {
      icon.classList.remove('fa-moon');
      icon.classList.add('fa-sun');
    } else {
      icon.classList.remove('fa-sun');
      icon.classList.add('fa-moon');
    }
  }
  
  // User Dropdown
  const userDropdownBtn = document.getElementById('userDropdownBtn');
  const userDropdown = document.getElementById('userDropdown');
  
  userDropdownBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    userDropdown.classList.toggle('show');
  });
  
  // Close dropdown when clicking outside
  document.addEventListener('click', function() {
    userDropdown.classList.remove('show');
  });
  
  // Sign Out
  const signOutBtn = document.getElementById('signOutBtn');
  signOutBtn.addEventListener('click', function() {
    fetch('/logout', {
      method: 'POST'
    }).then(() => {
      window.location.href = '/';
    });
  });
  
  // Navigation
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    item.addEventListener('click', function() {
      navItems.forEach(nav => nav.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  // Filter Toggle
  const filterBtn = document.getElementById('filterBtn');
  const filterOptions = document.getElementById('filterOptions');
  
  filterBtn.addEventListener('click', function() {
    filterOptions.classList.toggle('active');
  });
  
  // Apply Filters
  const applyFiltersBtn = document.getElementById('applyFiltersBtn');
  applyFiltersBtn.addEventListener('click', function() {
    const distance = document.getElementById('distanceFilter').value;
    const minPrice = document.getElementById('minPrice').value;
    const maxPrice = document.getElementById('maxPrice').value;
    const rating = document.getElementById('ratingFilter').value;
    
    // Filter suppliers based on criteria
    const filteredSuppliers = suppliers.filter(supplier => {
      const meetsDistance = distance === 'all' || supplier.distance <= parseInt(distance);
      const meetsPrice = (!minPrice || supplier.products.some(p => p.price >= parseInt(minPrice))) && 
                        (!maxPrice || supplier.products.some(p => p.price <= parseInt(maxPrice)));
      const meetsRating = rating === 'all' || supplier.rating >= parseInt(rating);
      
      return meetsDistance && meetsPrice && meetsRating;
    });
    
    renderSuppliers(filteredSuppliers);
    filterOptions.classList.remove('active');
  });
  
  // Supplier Modal and Data
  const supplierModal = document.getElementById('supplierModal');
  const closeSupplierModal = document.getElementById('closeSupplierModal');
  
  const suppliers = [
    {
      id: 1,
      name: "Fresh Farm Produce",
      phone: "+91 98765 43210",
      email: "freshfarm@example.com",
      address: "123 Green Lane, Bangalore, Karnataka",
      distance: 3, // km
      rating: 4.5,
      reviews: 24,
      products: [
        { id: 1, name: "Organic Tomatoes", price: 50 },
        { id: 2, name: "Fresh Potatoes", price: 30 },
        { id: 3, name: "Carrots", price: 40 }
      ],
      reviewsList: [
        { author: "Vendor A", date: "2023-05-15", rating: 5, text: "Excellent quality produce, always fresh!" },
        { author: "Vendor B", date: "2023-04-28", rating: 4, text: "Good prices and reliable delivery." }
      ]
    },
    {
      id: 2,
      name: "Grain Masters",
      phone: "+91 98765 43211",
      email: "grainmasters@example.com",
      address: "456 Harvest Road, Bangalore, Karnataka",
      distance: 5,
      rating: 4.2,
      reviews: 18,
      products: [
        { id: 4, name: "Basmati Rice", price: 65 },
        { id: 5, name: "Whole Wheat Flour", price: 40 },
        { id: 6, name: "Jowar Flour", price: 35 }
      ],
      reviewsList: [
        { author: "Vendor C", date: "2023-06-10", rating: 4, text: "Consistent quality grains." },
        { author: "Vendor D", date: "2023-05-22", rating: 5, text: "Best rice in town!" }
      ]
    },
    {
      id: 3,
      name: "Dairy Delights",
      phone: "+91 98765 43212",
      email: "dairydelights@example.com",
      address: "789 Milk Street, Bangalore, Karnataka",
      distance: 7,
      rating: 4.7,
      reviews: 32,
      products: [
        { id: 7, name: "Fresh Milk", price: 50 },
        { id: 8, name: "Paneer", price: 180 },
        { id: 9, name: "Yogurt", price: 60 }
      ],
      reviewsList: [
        { author: "Vendor E", date: "2023-07-05", rating: 5, text: "Fresh dairy products every morning." },
        { author: "Vendor F", date: "2023-06-18", rating: 4, text: "Great quality paneer." }
      ]
    },
    {
      id: 4,
      name: "Spice World",
      phone: "+91 98765 43213",
      email: "spiceworld@example.com",
      address: "321 Masala Lane, Bangalore, Karnataka",
      distance: 4,
      rating: 4.3,
      reviews: 15,
      products: [
        { id: 10, name: "Turmeric Powder", price: 120 },
        { id: 11, name: "Cumin Seeds", price: 90 },
        { id: 12, name: "Coriander Powder", price: 100 }
      ],
      reviewsList: [
        { author: "Vendor G", date: "2023-05-30", rating: 4, text: "Authentic spices with good aroma." },
        { author: "Vendor H", date: "2023-05-12", rating: 5, text: "Best place for bulk spice purchases." }
      ]
    },
    {
      id: 5,
      name: "Organic Valley",
      phone: "+91 98765 43214",
      email: "organicvalley@example.com",
      address: "654 Green Road, Bangalore, Karnataka",
      distance: 8,
      rating: 4.8,
      reviews: 28,
      products: [
        { id: 13, name: "Organic Apples", price: 80 },
        { id: 14, name: "Organic Bananas", price: 40 },
        { id: 15, name: "Organic Spinach", price: 75 }
      ],
      reviewsList: [
        { author: "Vendor I", date: "2023-07-12", rating: 5, text: "Worth the premium for organic quality." },
        { author: "Vendor J", date: "2023-06-25", rating: 4, text: "Reliable organic supplier." }
      ]
    },
    {
      id: 6,
      name: "Vegetable King",
      phone: "+91 98765 43215",
      email: "vegeking@example.com",
      address: "987 Veggie Plaza, Bangalore, Karnataka",
      distance: 6,
      rating: 4.1,
      reviews: 20,
      products: [
        { id: 16, name: "Bell Peppers", price: 60 },
        { id: 17, name: "Cucumbers", price: 35 },
        { id: 18, name: "Brinjal", price: 45 }
      ],
      reviewsList: [
        { author: "Vendor K", date: "2023-06-15", rating: 4, text: "Good variety of vegetables." },
        { author: "Vendor L", date: "2023-05-28", rating: 3, text: "Sometimes inconsistent quality." }
      ]
    },
    {
      id: 7,
      name: "Fruit Paradise",
      phone: "+91 98765 43216",
      email: "fruitparadise@example.com",
      address: "159 Orchard Road, Bangalore, Karnataka",
      distance: 9,
      rating: 4.6,
      reviews: 25,
      products: [
        { id: 19, name: "Mangoes", price: 70 },
        { id: 20, name: "Grapes", price: 90 },
        { id: 21, name: "Pomegranates", price: 120 }
      ],
      reviewsList: [
        { author: "Vendor M", date: "2023-07-08", rating: 5, text: "Best seasonal fruits available." },
        { author: "Vendor N", date: "2023-06-20", rating: 4, text: "Excellent mangoes during season." }
      ]
    },
    {
      id: 8,
      name: "Nut House",
      phone: "+91 98765 43217",
      email: "nuthouse@example.com",
      address: "753 Nut Street, Bangalore, Karnataka",
      distance: 10,
      rating: 4.4,
      reviews: 16,
      products: [
        { id: 22, name: "Almonds", price: 500 },
        { id: 23, name: "Cashews", price: 600 },
        { id: 24, name: "Walnuts", price: 450 }
      ],
      reviewsList: [
        { author: "Vendor O", date: "2023-06-05", rating: 4, text: "Good quality dry fruits." },
        { author: "Vendor P", date: "2023-05-15", rating: 5, text: "Premium nuts at reasonable prices." }
      ]
    },
    {
      id: 9,
      name: "Herb Garden",
      phone: "+91 98765 43218",
      email: "herbgarden@example.com",
      address: "852 Herb Lane, Bangalore, Karnataka",
      distance: 4,
      rating: 4.7,
      reviews: 19,
      products: [
        { id: 25, name: "Basil", price: 40 },
        { id: 26, name: "Mint", price: 30 },
        { id: 27, name: "Coriander", price: 25 }
      ],
      reviewsList: [
        { author: "Vendor Q", date: "2023-07-01", rating: 5, text: "Fresh herbs always available." },
        { author: "Vendor R", date: "2023-06-10", rating: 4, text: "Great for restaurant quantities." }
      ]
    },
    {
      id: 10,
      name: "Beverage Corner",
      phone: "+91 98765 43219",
      email: "beveragecorner@example.com",
      address: "963 Drink Avenue, Bangalore, Karnataka",
      distance: 7,
      rating: 4.0,
      reviews: 14,
      products: [
        { id: 28, name: "Green Tea", price: 200 },
        { id: 29, name: "Coffee Beans", price: 300 },
        { id: 30, name: "Herbal Tea", price: 180 }
      ],
      reviewsList: [
        { author: "Vendor S", date: "2023-06-22", rating: 4, text: "Good selection of beverages." },
        { author: "Vendor T", date: "2023-05-30", rating: 3, text: "Prices slightly higher than market." }
      ]
    },
    {
      id: 11,
      name: "Frozen Foods",
      phone: "+91 98765 43220",
      email: "frozenfoods@example.com",
      address: "741 Cold Street, Bangalore, Karnataka",
      distance: 12,
      rating: 3.9,
      reviews: 11,
      products: [
        { id: 31, name: "Frozen Peas", price: 80 },
        { id: 32, name: "Frozen Corn", price: 70 },
        { id: 33, name: "Frozen Mixed Vegetables", price: 90 }
      ],
      reviewsList: [
        { author: "Vendor U", date: "2023-06-18", rating: 4, text: "Convenient for off-season veggies." },
        { author: "Vendor V", date: "2023-05-25", rating: 3, text: "Delivery sometimes delayed." }
      ]
    },
    {
      id: 12,
      name: "Exotic Imports",
      phone: "+91 98765 43221",
      email: "exoticimports@example.com",
      address: "369 Import Plaza, Bangalore, Karnataka",
      distance: 15,
      rating: 4.9,
      reviews: 35,
      products: [
        { id: 34, name: "Avocados", price: 150 },
        { id: 35, name: "Kiwis", price: 120 },
        { id: 36, name: "Dragon Fruit", price: 200 }
      ],
      reviewsList: [
        { author: "Vendor W", date: "2023-07-15", rating: 5, text: "Best place for exotic fruits." },
        { author: "Vendor X", date: "2023-06-28", rating: 5, text: "Consistent quality imports." }
      ]
    }
  ];
  
  // Render suppliers list
  const suppliersList = document.getElementById('suppliersList');
  
  function renderSuppliers(suppliersToRender = suppliers) {
    suppliersList.innerHTML = '';
    suppliersToRender.forEach(supplier => {
      const supplierCard = document.createElement('div');
      supplierCard.className = 'supplier-card';
      supplierCard.innerHTML = `
        <div class="supplier-header">
          <img src="{{ url_for('static', filename='images/default-supplier.jpg') }}" alt="${supplier.name}" class="supplier-avatar">
          <div class="supplier-info">
            <div class="supplier-name">${supplier.name}</div>
            <div class="supplier-rating">
              <span class="star">${'★'.repeat(Math.floor(supplier.rating))}${'☆'.repeat(5 - Math.floor(supplier.rating))}</span>
              <span>(${supplier.reviews})</span>
            </div>
          </div>
        </div>
        <div class="supplier-products">
          ${supplier.products.slice(0, 2).map(product => `
            <div class="product-item">
              <div class="product-name">${product.name}</div>
              <div class="product-price">₹${product.price}/kg</div>
              <div class="quantity-control">
                <button class="quantity-btn minus" data-id="${product.id}">-</button>
                <input type="number" class="quantity-input" value="1" min="1" data-id="${product.id}">
                <button class="quantity-btn plus" data-id="${product.id}">+</button>
              </div>
              <button class="add-cart-btn" data-supplier="${supplier.id}" data-product="${product.id}">Add</button>
            </div>
          `).join('')}
          ${supplier.products.length > 2 ? '<div class="more-products">+ ' + (supplier.products.length - 2) + ' more</div>' : ''}
          <div class="add-to-cart">
            <button class="btn view-supplier-btn" data-id="${supplier.id}">View Supplier</button>
          </div>
        </div>
      `;
      suppliersList.appendChild(supplierCard);
    });
    
    // Add event listeners to view buttons
    document.querySelectorAll('.view-supplier-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const supplierId = parseInt(this.getAttribute('data-id'));
        const supplier = suppliers.find(s => s.id === supplierId);
        openSupplierModal(supplier);
      });
    });
    
    // Add event listeners to quantity controls
    setupQuantityControls();
  }
  
  function setupQuantityControls() {
    document.querySelectorAll('.quantity-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const input = this.parentElement.querySelector('.quantity-input');
        let value = parseInt(input.value);
        if (this.classList.contains('plus')) {
          value++;
        } else {
          value = Math.max(1, value - 1);
        }
        input.value = value;
      });
    });
  }
  
  function openSupplierModal(supplier) {
    document.getElementById('modalSupplierName').textContent = supplier.name;
    document.getElementById('modalSupplierPhone').textContent = supplier.phone;
    document.getElementById('modalSupplierEmail').textContent = supplier.email;
    document.getElementById('modalSupplierAddress').textContent = supplier.address;
    
    const starsElement = document.querySelector('.profile-info .stars');
    starsElement.textContent = '★'.repeat(Math.floor(supplier.rating)) + '☆'.repeat(5 - Math.floor(supplier.rating));
    document.querySelector('.review-count').textContent = `(${supplier.reviews} reviews)`;
    
    const productsList = document.getElementById('modalProductsList');
    productsList.innerHTML = supplier.products.map(product => `
      <li>
        <span>${product.name}</span>
        <span>₹${product.price}/kg</span>
        <div class="modal-quantity">
          <button class="quantity-btn minus" data-id="${product.id}">-</button>
          <input type="number" class="quantity-input" value="1" min="1" data-id="${product.id}">
          <button class="quantity-btn plus" data-id="${product.id}">+</button>
          <button class="add-cart-btn" data-supplier="${supplier.id}" data-product="${product.id}">Add</button>
        </div>
      </li>
    `).join('');
    
    const reviewsContainer = document.getElementById('reviewsContainer');
    reviewsContainer.innerHTML = supplier.reviewsList.map(review => `
      <div class="review-item">
        <div class="review-header">
          <span class="review-author">${review.author}</span>
          <span class="review-date">${review.date}</span>
        </div>
        <div class="review-rating">${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</div>
        <div class="review-text">${review.text}</div>
      </div>
    `).join('');
    
    supplierModal.classList.add('active');
    setupQuantityControls();
    setupAddToCartButtons();
  }
  
  closeSupplierModal.addEventListener('click', function() {
    supplierModal.classList.remove('active');
  });
  
  supplierModal.addEventListener('click', function(e) {
    if (e.target === supplierModal) {
      supplierModal.classList.remove('active');
    }
  });
  
  // Cart functionality
  const cartSidebar = document.getElementById('cartSidebar');
  const closeCartBtn = document.getElementById('closeCartBtn');
  const cartItems = document.getElementById('cartItems');
  const cartSubtotal = document.getElementById('cartSubtotal');
  const cartDelivery = document.getElementById('cartDelivery');
  const cartTotal = document.getElementById('cartTotal');
  const checkoutBtn = document.getElementById('checkoutBtn');
  
  let cart = [];
  
  function setupAddToCartButtons() {
    document.querySelectorAll('.add-cart-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const supplierId = parseInt(this.getAttribute('data-supplier'));
        const productId = parseInt(this.getAttribute('data-product'));
        const quantityInput = this.parentElement.querySelector('.quantity-input');
        const quantity = parseInt(quantityInput.value);
        
        const supplier = suppliers.find(s => s.id === supplierId);
        const product = supplier.products.find(p => p.id === productId);
        
        const existingItem = cart.find(item => 
          item.supplierId === supplierId && item.productId === productId
        );
        
        if (existingItem) {
          existingItem.quantity += quantity;
        } else {
          cart.push({
            id: Date.now(),
            supplierId,
            supplier: supplier.name,
            productId,
            name: product.name,
            price: product.price,
            quantity
          });
        }
        
        updateCart();
        showCartNotification();
      });
    });
  }
  
  function showCartNotification() {
    const notification = document.createElement('div');
    notification.className = 'cart-notification';
    notification.textContent = 'Item added to cart!';
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.classList.add('fade-out');
      setTimeout(() => notification.remove(), 500);
    }, 2000);
  }
  
  function updateCart() {
    cartItems.innerHTML = '';
    
    if (cart.length === 0) {
      cartItems.innerHTML = '<p>Your cart is empty</p>';
      cartSubtotal.textContent = '₹0.00';
      cartDelivery.textContent = '₹0.00';
      cartTotal.textContent = '₹0.00';
      return;
    }
    
    let subtotal = 0;
    
    cart.forEach(item => {
      subtotal += item.price * item.quantity;
      
      const cartItem = document.createElement('div');
      cartItem.className = 'cart-item';
      cartItem.innerHTML = `
        <img src="{{ url_for('static', filename='images/default-product.jpg') }}" alt="${item.name}" class="cart-item-img">
        <div class="cart-item-details">
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-supplier">${item.supplier}</div>
          <div class="cart-item-price">₹${item.price * item.quantity}</div>
          <div class="cart-item-actions">
            <span class="remove-item" data-id="${item.id}">Remove</span>
          </div>
        </div>
      `;
      cartItems.appendChild(cartItem);
    });
    
    const delivery = subtotal > 500 ? 0 : 50;
    const total = subtotal + delivery;
    
    cartSubtotal.textContent = `₹${subtotal.toFixed(2)}`;
    cartDelivery.textContent = `₹${delivery.toFixed(2)}`;
    cartTotal.textContent = `₹${total.toFixed(2)}`;
    
    document.querySelectorAll('.remove-item').forEach(btn => {
      btn.addEventListener('click', function() {
        const itemId = parseInt(this.getAttribute('data-id'));
        cart = cart.filter(item => item.id !== itemId);
        updateCart();
      });
    });
  }
  
  // Show cart button
  const showCartBtn = document.createElement('button');
  showCartBtn.className = 'btn show-cart-btn';
  showCartBtn.innerHTML = '<i class="fas fa-shopping-cart"></i>';
  showCartBtn.style.position = 'fixed';
  showCartBtn.style.bottom = '20px';
  showCartBtn.style.right = '20px';
  showCartBtn.style.zIndex = '1000';
  showCartBtn.addEventListener('click', function() {
    cartSidebar.classList.add('active');
  });
  document.body.appendChild(showCartBtn);
  
  closeCartBtn.addEventListener('click', function() {
    cartSidebar.classList.remove('active');
  });
  
  checkoutBtn.addEventListener('click', function() {
    if (cart.length === 0) {
      alert('Your cart is empty!');
      return;
    }
    
    alert('Proceeding to checkout...');
    // In a real app, you would redirect to checkout page
  });
  
  // Search functionality
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.querySelector('.search-btn');
  
  function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    if (searchTerm.length > 0) {
      const filteredSuppliers = suppliers.filter(supplier => 
        supplier.name.toLowerCase().includes(searchTerm) ||
        supplier.products.some(p => p.name.toLowerCase().includes(searchTerm))
      );
      renderSuppliers(filteredSuppliers);
    } else {
      renderSuppliers();
    }
  }
  
  searchBtn.addEventListener('click', handleSearch);
  searchInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      handleSearch();
    }
  });
  
  // Initialize
  renderSuppliers();
  updateCart();
  setupAddToCartButtons();
});