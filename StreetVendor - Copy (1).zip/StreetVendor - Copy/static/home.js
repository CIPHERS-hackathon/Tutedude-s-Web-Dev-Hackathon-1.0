// Theme Toggle
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = themeToggle.querySelector('i');

// Check for saved theme preference
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.body.classList.add(savedTheme);
    if (savedTheme === 'dark-theme') {
        themeIcon.classList.replace('fa-moon', 'fa-sun');
    }
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    
    // Save theme preference
    const currentTheme = document.body.classList.contains('dark-theme') ? 'dark-theme' : '';
    localStorage.setItem('theme', currentTheme);
    
    if (document.body.classList.contains('dark-theme')) {
        themeIcon.classList.replace('fa-moon', 'fa-sun');
    } else {
        themeIcon.classList.replace('fa-sun', 'fa-moon');
    }
});

// Profile Menu Toggle
const profileIcon = document.getElementById('profile-icon');
const profileMenu = document.getElementById('profile-menu');

profileIcon.addEventListener('click', (e) => {
    e.stopPropagation();
    profileMenu.classList.toggle('show');
});

// Close profile menu when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.user-profile')) {
        profileMenu.classList.remove('show');
    }
});

// Filter Toggle
const filterBtn = document.getElementById('filter-btn');
const filterOptions = document.getElementById('filter-options');

filterBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    filterOptions.classList.toggle('show');
});

// Close filter when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.filter-section')) {
        filterOptions.classList.remove('show');
    }
});


// Filter functionality
const typeFilter = document.getElementById('type-filter');
const priceFilter = document.getElementById('price-filter');
const weightFilter = document.getElementById('weight-filter');

function applyFilters() {
    const typeValue = typeFilter.value;
    const priceValue = priceFilter.value;
    const weightValue = weightFilter.value;
    
    let filteredFish = [...fishData];
    
    // Type filter - now properly checks the type property
    if (typeValue !== 'all') {
        filteredFish = filteredFish.filter(fish => {
            if (!fish.type) {
                // Fallback for fish without type property
                if (typeValue === 'freshwater') {
                    return freshwaterFish.includes(fish.name.split(' ')[0]);
                } else if (typeValue === 'saltwater') {
                    return saltwaterFish.includes(fish.name.split(' ')[0]);
                } else if (typeValue === 'shellfish') {
                    return shellfish.includes(fish.name.split(' ')[0]);
                }
                return true;
            }
            return fish.type === typeValue;
        });
    }
    
    // Price filter (unchanged - works fine)
    if (priceValue !== 'all') {
        const [min, max] = priceValue.includes('+') ? 
            [parseInt(priceValue.replace('+', '')), Infinity] : 
            priceValue.split('-').map(Number);
        
        filteredFish = filteredFish.filter(fish => {
            const price = fish.pricePerKg * fish.weightInKg;
            return price >= min && (max === Infinity || price <= max);
        });
    }
    
    // Weight filter (unchanged - works fine)
    if (weightValue !== 'all') {
        const [min, max] = weightValue.includes('+') ? 
            [parseFloat(weightValue.replace('+', '')), Infinity] : 
            weightValue.split('-').map(Number);
        
        filteredFish = filteredFish.filter(fish => {
            return fish.weightInKg >= min && (max === Infinity || fish.weightInKg <= max);
        });
    }
    
    displayFish(filteredFish);
}

// Add event listeners to filters
typeFilter.addEventListener('change', applyFilters);
priceFilter.addEventListener('change', applyFilters);
weightFilter.addEventListener('change', applyFilters);

function toggleDetails(header) {
  const details = header.nextElementSibling;
  details.style.display = details.style.display === "block" ? "none" : "block";
}
document.getElementById('search-input').addEventListener('input', function () {
  const query = this.value.toLowerCase();
  document.querySelectorAll('.supplier-card').forEach(card => {
    const text = card.textContent.toLowerCase();
    card.style.display = text.includes(query) ? 'block' : 'none';
  });
});

// Add this to home.js
let currentPage = 1;
const itemsPerPage = 12; // Show 12 items per page

// Sample data - in a real app this would come from an API
const supplierData = [
  // Add your supplier data here (at least 12 items for testing)
  { id: 1, name: "Fresh Fish Co.", products: "Salmon, Tuna, Cod", location: "2km away", rating: "4.5" },
  { id: 2, name: "Ocean Harvest", products: "Shrimp, Lobster, Crab", location: "5km away", rating: "4.2" },
  // Add more suppliers...
];

function displaySuppliers(page = 1) {
  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedItems = supplierData.slice(startIndex, endIndex);
  
  const suppliersList = document.getElementById('suppliersList');
  suppliersList.innerHTML = '';
  
  paginatedItems.forEach(supplier => {
    const card = document.createElement('div');
    card.className = 'supplier-card';
    card.innerHTML = `
      <div class="supplier-header" onclick="toggleDetails(this)">
        <h3>${supplier.name}</h3>
        <span class="rating">${supplier.rating} ★</span>
      </div>
      <div class="supplier-details">
        <p><strong>Products:</strong> ${supplier.products}</p>
        <p><strong>Location:</strong> ${supplier.location}</p>
        <button class="contact-btn">Contact Supplier</button>
      </div>
    `;
    suppliersList.appendChild(card);
  });
  
  // Update pagination controls
  updatePaginationControls();
}

function updatePaginationControls() {
  const totalPages = Math.ceil(supplierData.length / itemsPerPage);
  let paginationHTML = `
    <div class="pagination">
      <button ${currentPage === 1 ? 'disabled' : ''} onclick="changePage(${currentPage - 1})">Previous</button>
      <span>Page ${currentPage} of ${totalPages}</span>
      <button ${currentPage === totalPages ? 'disabled' : ''} onclick="changePage(${currentPage + 1})">Next</button>
    </div>
  `;
  
  document.querySelector('.suppliers-section').insertAdjacentHTML('beforeend', paginationHTML);
}

function changePage(page) {
  if (page < 1 || page > Math.ceil(supplierData.length / itemsPerPage)) return;
  currentPage = page;
  displaySuppliers(currentPage);
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  displaySuppliers();
  
  // Search functionality
  document.getElementById('searchInput').addEventListener('input', function() {
    const query = this.value.toLowerCase();
    document.querySelectorAll('.supplier-card').forEach(card => {
      const text = card.textContent.toLowerCase();
      card.style.display = text.includes(query) ? 'block' : 'none';
    });
  });
});