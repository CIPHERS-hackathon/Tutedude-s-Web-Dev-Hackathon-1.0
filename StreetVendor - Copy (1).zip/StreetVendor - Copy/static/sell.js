const form = document.getElementById('product-form');
const list = document.getElementById('product-list');
let products = [];

form.addEventListener('submit', function (e) {
  e.preventDefault();

  const name = document.getElementById('product-name').value.trim();
  const quantity = document.getElementById('product-quantity').value.trim();
  const price = document.getElementById('product-price').value.trim();
  const category = document.getElementById('product-category').value;

  const newProduct = { name, quantity, price, category };
  products.push(newProduct);
  renderProducts();
  form.reset();
});

function renderProducts() {
  list.innerHTML = '';
  products.forEach((product, index) => {
    const card = document.createElement('div');
    card.className = 'supplier-card';
    card.innerHTML = `
      <div class="supplier-header">${product.name} - ₹${product.price}/kg</div>
      <div class="supplier-details" style="display: block;">
        <p><strong>Quantity:</strong> ${product.quantity} kg</p>
        <p><strong>Category:</strong> ${product.category}</p>
        <button class="btn" onclick="editProduct(${index})">Edit</button>
        <button class="btn" onclick="deleteProduct(${index})">Delete</button>
      </div>
    `;
    list.appendChild(card);
  });
}

function deleteProduct(index) {
  products.splice(index, 1);
  renderProducts();
}

function editProduct(index) {
  const p = products[index];
  document.getElementById('product-name').value = p.name;
  document.getElementById('product-quantity').value = p.quantity;
  document.getElementById('product-price').value = p.price;
  document.getElementById('product-category').value = p.category;

  products.splice(index, 1); // remove so it'll be re-added on submit
  renderProducts();
}
document.getElementById("product-form").addEventListener("submit", function (e) {
  e.preventDefault();

  const product = {
    name: document.getElementById("product-name").value,
    quantity: document.getElementById("product-quantity").value,
    price: document.getElementById("product-price").value,
    category: document.getElementById("product-category").value,
    unit: "kg" // or from an input field
  };

  fetch("http://localhost:5000/add-product", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product)
  })
  .then(res => res.json())
  .then(data => {
    console.log("Saved:", data);
    // Optionally reload the list
  });
});
