document.addEventListener('DOMContentLoaded', function() {
  // Theme Toggle
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const body = document.body;
  
  // Check for saved theme preference
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) {
    body.classList.add(savedTheme);
    updateThemeIcon();
  }
  
  themeToggleBtn.addEventListener('click', function() {
    body.classList.toggle('dark-theme');
    const currentTheme = body.classList.contains('dark-theme') ? 'dark-theme' : 'light-theme';
    localStorage.setItem('theme', currentTheme);
    updateThemeIcon();
  });
  
  function updateThemeIcon() {
    const icon = themeToggleBtn.querySelector('i');
    if (body.classList.contains('dark-theme')) {
      icon.classList.remove('fa-moon');
      icon.classList.add('fa-sun');
    } else {
      icon.classList.remove('fa-sun');
      icon.classList.add('fa-moon');
    }
  }
  
  // User Dropdown
  const userDropdownBtn = document.getElementById('userDropdownBtn');
  const userDropdown = document.getElementById('userDropdown');
  
  userDropdownBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    userDropdown.classList.toggle('show');
  });
  
  // Close dropdown when clicking outside
  document.addEventListener('click', function() {
    userDropdown.classList.remove('show');
  });
  
  // Sign Out
  const signOutBtn = document.getElementById('signOutBtn');
  signOutBtn.addEventListener('click', function() {
    fetch('/logout', {
      method: 'POST'
    }).then(() => {
      window.location.href = '/';
    });
  });

  // Sample purchase data - replace with actual data from your backend
  const purchases = [
    {
      id: 1,
      date: "2023-10-15",
      supplier: "Fresh Farms Co.",
      items: [
        { name: "Organic Tomatoes", quantity: "20kg", unit_price: "₹45", total: "₹900" },
        { name: "Bell Peppers", quantity: "10kg", unit_price: "₹60", total: "₹600" }
      ],
      total: "₹1500",
      status: "paid"
    },
    {
      id: 2,
      date: "2023-10-10",
      supplier: "Grain Valley",
      items: [
        { name: "Wheat Flour", quantity: "50kg", unit_price: "₹30", total: "₹1500" }
      ],
      total: "₹1500",
      status: "pending"
    },
    {
      id: 3,
      date: "2023-09-28",
      supplier: "Dairy Delight",
      items: [
        { name: "Fresh Milk", quantity: "20L", unit_price: "₹50", total: "₹1000" },
        { name: "Butter", quantity: "5kg", unit_price: "₹200", total: "₹1000" }
      ],
      total: "₹2000",
      status: "paid"
    },
    {
      id: 4,
      date: "2023-09-20",
      supplier: "Spice Kingdom",
      items: [
        { name: "Turmeric Powder", quantity: "5kg", unit_price: "₹120", total: "₹600" },
        { name: "Cumin Seeds", quantity: "3kg", unit_price: "₹90", total: "₹270" }
      ],
      total: "₹870",
      status: "paid"
    },
    {
      id: 5,
      date: "2023-09-15",
      supplier: "Organic Harvest",
      items: [
        { name: "Organic Apples", quantity: "15kg", unit_price: "₹80", total: "₹1200" },
        { name: "Organic Bananas", quantity: "12kg", unit_price: "₹40", total: "₹480" }
      ],
      total: "₹1680",
      status: "paid"
    },
    {
      id: 6,
      date: "2023-09-10",
      supplier: "Fresh Farms Co.",
      items: [
        { name: "Cucumbers", quantity: "25kg", unit_price: "₹35", total: "₹875" },
        { name: "Carrots", quantity: "18kg", unit_price: "₹45", total: "₹810" }
      ],
      total: "₹1685",
      status: "paid"
    },
    {
      id: 7,
      date: "2023-09-05",
      supplier: "Grain Valley",
      items: [
        { name: "Basmati Rice", quantity: "40kg", unit_price: "₹65", total: "₹2600" }
      ],
      total: "₹2600",
      status: "paid"
    },
    {
      id: 8,
      date: "2023-08-28",
      supplier: "Dairy Delight",
      items: [
        { name: "Paneer", quantity: "8kg", unit_price: "₹180", total: "₹1440" },
        { name: "Yogurt", quantity: "15L", unit_price: "₹60", total: "₹900" }
      ],
      total: "₹2340",
      status: "paid"
    },
    {
      id: 9,
      date: "2023-08-20",
      supplier: "Spice Kingdom",
      items: [
        { name: "Coriander Powder", quantity: "4kg", unit_price: "₹100", total: "₹400" },
        { name: "Red Chili Powder", quantity: "3kg", unit_price: "₹110", total: "₹330" }
      ],
      total: "₹730",
      status: "paid"
    },
    {
      id: 10,
      date: "2023-08-15",
      supplier: "Organic Harvest",
      items: [
        { name: "Organic Spinach", quantity: "8kg", unit_price: "₹75", total: "₹600" },
        { name: "Organic Potatoes", quantity: "25kg", unit_price: "₹35", total: "₹875" }
      ],
      total: "₹1475",
      status: "paid"
    },
    {
      id: 11,
      date: "2023-08-10",
      supplier: "Fresh Farms Co.",
      items: [
        { name: "Onions", quantity: "30kg", unit_price: "₹25", total: "₹750" },
        { name: "Garlic", quantity: "5kg", unit_price: "₹80", total: "₹400" }
      ],
      total: "₹1150",
      status: "paid"
    },
    {
      id: 12,
      date: "2023-08-05",
      supplier: "Grain Valley",
      items: [
        { name: "Whole Wheat Flour", quantity: "35kg", unit_price: "₹40", total: "₹1400" }
      ],
      total: "₹1400",
      status: "paid"
    },
    {
      id: 13,
      date: "2023-07-30",
      supplier: "Dairy Delight",
      items: [
        { name: "Cheese", quantity: "5kg", unit_price: "₹250", total: "₹1250" },
        { name: "Buttermilk", quantity: "10L", unit_price: "₹45", total: "₹450" }
      ],
      total: "₹1700",
      status: "paid"
    }
  ];

  // Available suppliers for filter dropdown
  const suppliers = [
    { id: 1, name: "Fresh Farms Co." },
    { id: 2, name: "Grain Valley" },
    { id: 3, name: "Dairy Delight" },
    { id: 4, name: "Spice Kingdom" },
    { id: 5, name: "Organic Harvest" }
  ];

  // Initialize UI
  renderPurchases(purchases);
  populateSupplierFilter();

  // Toggle transaction details
  document.querySelectorAll('.btn-details').forEach(btn => {
    btn.addEventListener('click', function() {
      const detailsRow = this.closest('tr').nextElementSibling;
      detailsRow.classList.toggle('active');
    });
  });

  // Initialize spending trend chart
  const ctx = document.getElementById('spendingTrendChart').getContext('2d');
  const spendingChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [{
        label: 'Monthly Spending (₹)',
        data: [12000, 18000, 15000, 22000, 19000, 25000],
        borderColor: '#28a745',
        backgroundColor: 'rgba(40, 167, 69, 0.1)',
        fill: true,
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: 'Monthly Spending Trends',
          font: {
            size: 16
          }
        }
      },
      scales: {
        y: {
          beginAtZero: false
        }
      }
    }
  });

  // Filter functionality
  const filterBtn = document.querySelector('.filter-btn');
  filterBtn.addEventListener('click', applyFilters);

  // Populate supplier filter dropdown
  function populateSupplierFilter() {
    const supplierSelect = document.getElementById('supplierSelect');
    suppliers.forEach(supplier => {
      const option = document.createElement('option');
      option.value = supplier.id;
      option.textContent = supplier.name;
      supplierSelect.appendChild(option);
    });
  }

  // Apply filters to purchases
  function applyFilters() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const supplierId = document.getElementById('supplierSelect').value;

    let filteredPurchases = purchases;

    // Date filter
    if (startDate) {
      filteredPurchases = filteredPurchases.filter(p => p.date >= startDate);
    }
    if (endDate) {
      filteredPurchases = filteredPurchases.filter(p => p.date <= endDate);
    }

    // Supplier filter
    if (supplierId && supplierId !== 'all') {
      const selectedSupplier = suppliers.find(s => s.id == supplierId);
      filteredPurchases = filteredPurchases.filter(p => p.supplier === selectedSupplier.name);
    }

    // Re-render filtered purchases
    renderPurchases(filteredPurchases);
    
    // Update chart with filtered data (simplified example)
    updateChartWithFilteredData(filteredPurchases);
  }

  // Update chart with filtered data
  function updateChartWithFilteredData(filteredPurchases) {
    // Group by month (simplified example)
    const monthlyData = filteredPurchases.reduce((acc, purchase) => {
      const month = purchase.date.substring(0, 7); // YYYY-MM
      acc[month] = (acc[month] || 0) + parseFloat(purchase.total.replace('₹', ''));
      return acc;
    }, {});

    // Update chart data
    spendingChart.data.labels = Object.keys(monthlyData);
    spendingChart.data.datasets[0].data = Object.values(monthlyData);
    spendingChart.update();
  }

  // Render purchases to the table
  function renderPurchases(purchasesToRender) {
    const tbody = document.querySelector('.transactions-table tbody');
    tbody.innerHTML = '';

    if (purchasesToRender.length === 0) {
      const row = document.createElement('tr');
      row.innerHTML = `<td colspan="6" class="no-results">No purchases found matching your filters</td>`;
      tbody.appendChild(row);
      return;
    }

    purchasesToRender.forEach(purchase => {
      // Main row
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${purchase.date}</td>
        <td>${purchase.supplier}</td>
        <td>${purchase.items.length} items</td>
        <td>${purchase.total}</td>
        <td><span class="status-badge ${purchase.status}">${purchase.status}</span></td>
        <td><button class="btn-details">View</button></td>
      `;
      tbody.appendChild(row);

      // Details row
      const detailsRow = document.createElement('tr');
      detailsRow.className = 'details-row';
      detailsRow.innerHTML = `
        <td colspan="6">
          <div class="item-details">
            <h4>Purchased Items</h4>
            <table class="items-table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Quantity</th>
                  <th>Unit Price</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                ${purchase.items.map(item => `
                  <tr>
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>${item.unit_price}</td>
                    <td>${item.total}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </td>
      `;
      tbody.appendChild(detailsRow);
    });

    // Reattach event listeners
    document.querySelectorAll('.btn-details').forEach(btn => {
      btn.addEventListener('click', function() {
        const detailsRow = this.closest('tr').nextElementSibling;
        detailsRow.classList.toggle('active');
      });
    });
  }

  // Initialize summary cards
  updateSummaryCards(purchases);

  function updateSummaryCards(purchasesData) {
    // Total spent
    const totalSpent = purchasesData.reduce((sum, purchase) => {
      return sum + parseFloat(purchase.total.replace('₹', ''));
    }, 0);
    document.querySelector('.summary-card:nth-child(1) p').textContent = `₹${totalSpent.toFixed(2)}`;

    // Top supplier
    const supplierTotals = purchasesData.reduce((acc, purchase) => {
      acc[purchase.supplier] = (acc[purchase.supplier] || 0) + parseFloat(purchase.total.replace('₹', ''));
      return acc;
    }, {});

    let topSupplier = 'None';
    let topAmount = 0;
    for (const [supplier, amount] of Object.entries(supplierTotals)) {
      if (amount > topAmount) {
        topSupplier = supplier;
        topAmount = amount;
      }
    }

    if (topSupplier !== 'None') {
      document.querySelector('.summary-card:nth-child(2) p').textContent = topSupplier;
      document.querySelector('.summary-card:nth-child(2) small').textContent = `₹${topAmount.toFixed(2)} spent`;
    }
  }
});